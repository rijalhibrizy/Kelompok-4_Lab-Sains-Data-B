# Mulai di sini

Paket ini adalah paket data dan dokumentasi awal, bukan source code aplikasi.

1. Baca `README_PAKET_DATA.md`.
2. Mulai pengumpulan data primer menggunakan `docs/INSTRUMEN_LAPANGAN.md`.
3. Isi `data/master_bahan_template.csv` setelah stok diperiksa langsung.
4. Catat setiap perubahan di `data/riwayat_stok_template.csv`.
5. Gunakan referensi publik pada `docs/REFERENSI_DAN_METODOLOGI.md` sesuai batasan.

**Penting:** Jangan menyajikan template kosong atau daftar komoditas usulan sebagai data aktual warung.
