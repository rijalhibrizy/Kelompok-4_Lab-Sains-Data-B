# Paket Data Rameza Stock

Paket ini disusun untuk membantu persiapan data laporan dan pengembangan aplikasi Rameza Stock (pengelolaan persediaan manual) dengan konteks lokasi Tembalang, Kota Semarang.

## Isi folder
- `data/konteks_penduduk_tembalang_2025.csv`: data penduduk BPS 2025. Total 204.865 merupakan hasil penjumlahan angka laki-laki dan perempuan.
- `data/sumber_konteks_resmi.csv`: ringkasan beberapa indikator publik dan batasan penggunaannya.
- `data/kamus_komoditas_awal.csv`: daftar kandidat bahan umum untuk membantu membuat daftar observasi; bukan bukti bahwa warung memakai semua bahan ini.
- `data/master_bahan_template.csv`: template kosong untuk stok aktual warung.
- `data/riwayat_stok_template.csv`: template pencatatan pembaruan stok.
- `data/pemasok_template.csv`: template data pemasok jika diperlukan.
- `data/harga_pangan_template.csv`: template pencatatan harga dari PIHPS.
- `docs/REFERENSI_DAN_METODOLOGI.md`: sumber dan metode.
- `docs/INSTRUMEN_LAPANGAN.md`: pertanyaan wawancara dan checklist observasi.
- `docs/ANALISIS_KEBUTUHAN_AWAL.md`: kebutuhan awal sistem dan batasan.
- `docs/KERANGKA_LAPORAN.md`: rancangan susunan laporan.

## Penting
Tidak ada stok, transaksi, identitas warung, pemasok aktual, atau hasil wawancara yang direkayasa. Kolom template dibiarkan kosong karena harus diisi dari observasi/wawancara warung yang benar-benar menjadi objek proyek. Jangan masukkan data contoh sebagai data penelitian.

## Cara pakai di VS Code
1. Ekstrak ZIP.
2. Salin folder `data` dan `docs` ke folder proyek Rameza Stock (atau salin seluruh isi paket).
3. Buka CSV dengan Excel/LibreOffice atau ekstensi CSV di VS Code.
4. Isi template hanya setelah data dikonfirmasi ke pemilik/pegawai dan/atau pemeriksaan fisik.
5. Simpan catatan tanggal, petugas, satuan, dan sumber setiap nilai.

## Catatan teknis
File CSV memakai UTF-8 dengan BOM agar karakter Indonesia lebih mudah dibaca di Excel. Gunakan satuan konsisten (kg, gram, liter, ml, butir, pcs); jangan mencampur satuan tanpa konversi yang terdokumentasi.
