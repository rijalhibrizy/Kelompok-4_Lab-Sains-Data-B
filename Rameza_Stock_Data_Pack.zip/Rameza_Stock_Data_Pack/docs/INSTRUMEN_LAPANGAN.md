# Instrumen wawancara dan observasi Rameza Stock

## A. Pertanyaan wawancara pemilik/pegawai
1. Bahan makanan apa saja yang rutin disimpan dan digunakan?
2. Siapa yang memeriksa stok dan seberapa sering?
3. Bagaimana stok dihitung (ditimbang, dihitung satuan, atau perkiraan)?
4. Di mana jumlah stok saat ini dicatat?
5. Bagaimana pemilik mengetahui bahan yang hampir habis?
6. Bagaimana proses menentukan jumlah bahan yang perlu dibeli?
7. Siapa pemasok untuk masing-masing bahan (jika bersedia dicatat)?
8. Masalah apa yang paling sering terjadi: stok habis, kelebihan stok, bahan rusak, salah catat, atau lainnya?
9. Informasi apa yang paling dibutuhkan pemilik dari aplikasi?
10. Siapa yang akan memasukkan dan melihat data di aplikasi?
11. Seberapa sering pembaruan stok sebaiknya dilakukan?
12. Apakah pemilik mengizinkan pencatatan nama usaha, foto, atau dokumen? Jika tidak, gunakan anonimisasi.

## B. Checklist observasi
- [ ] Daftar bahan yang benar-benar ada di lokasi.
- [ ] Satuan pengukuran setiap bahan.
- [ ] Jumlah fisik dihitung bersama pegawai.
- [ ] Kondisi bahan (baik/rusak/kedaluwarsa bila relevan).
- [ ] Lokasi penyimpanan.
- [ ] Cara pencatatan yang sedang digunakan.
- [ ] Bukti pembelian atau catatan stok yang diizinkan.
- [ ] Batas minimum stok berdasarkan kebijakan pemilik.
- [ ] Tanggal, waktu, dan petugas observasi dicatat.
- [ ] Pemilik/pegawai mengonfirmasi hasil pencatatan.

## C. Prosedur pencatatan
1. Minta izin sebelum mengambil foto atau menyalin dokumen.
2. Catat jumlah sesuai satuan yang disepakati.
3. Jangan mengubah perkiraan menjadi fakta; tandai jika jumlah hanya estimasi.
4. Untuk data yang sensitif, gunakan kode bahan/usaha.
5. Minta konfirmasi atas catatan akhir.

## D. Ukuran evaluasi aplikasi
- Apakah pengguna berhasil menambah/mengubah data bahan?
- Apakah update stok tersimpan?
- Apakah riwayat menunjukkan stok sebelum dan sesudah?
- Apakah status stok sesuai batas minimum yang disepakati?
- Berapa lama pengguna menyelesaikan satu pembaruan stok? (ukur saat uji coba)
- Apakah pengguna memahami dashboard dan laporan?
Catat hasil uji aktual; jangan mengisi nilai evaluasi sebelum pengujian.
