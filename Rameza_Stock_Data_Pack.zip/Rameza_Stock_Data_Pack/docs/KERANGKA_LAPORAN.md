# Kerangka laporan Rameza Stock

## BAB I — Pendahuluan
- Latar belakang: gunakan referensi BPS/PIHPS untuk konteks umum; jangan mengklaim masalah khusus warung sebelum wawancara.
- Identifikasi dan rumusan masalah: isi setelah masalah dikonfirmasi.
- Tujuan dan manfaat proyek.
- Ruang lingkup dan batasan.

## BAB II — Landasan Teori
- Sistem informasi persediaan.
- Manajemen inventori dan stok minimum.
- Basis data dan aplikasi web.
- ERP, SCM, CRM sesuai definisi/ketentuan dosen.
- Penelitian terdahulu dari jurnal yang benar-benar dibaca.

## BAB III — Metodologi
- Lokasi dan objek (Tembalang, Semarang; nama usaha hanya dengan izin).
- Teknik pengumpulan data: wawancara, observasi, dokumentasi, studi pustaka.
- Instrumen dan prosedur pencatatan.
- Teknik analisis kebutuhan.

## BAB IV — Analisis dan Perancangan
- Profil usaha berdasarkan data yang diizinkan.
- Proses bisnis berjalan (AS-IS).
- Masalah yang ditemukan beserta bukti.
- Proses usulan (TO-BE).
- Kebutuhan fungsional/nonfungsional.
- Rancangan proses, basis data, dan antarmuka.
- Pemetaan modul ERP/SCM/CRM terhadap instruksi tugas.

## BAB V — Implementasi dan Pengujian
- Teknologi dan struktur aplikasi.
- Implementasi fitur.
- Data awal yang sumbernya jelas.
- Skenario pengujian dan hasil aktual.
- Evaluasi pengguna bila dilakukan.

## BAB VI — Kesimpulan dan Saran
- Kesimpulan harus menjawab tujuan berdasarkan hasil nyata.
- Saran pengembangan berdasarkan keterbatasan yang ditemukan.

## Lampiran
- Daftar pertanyaan wawancara.
- Checklist observasi.
- Data stok yang telah diizinkan untuk dipakai.
- Bukti pengujian.
- Referensi lengkap.
