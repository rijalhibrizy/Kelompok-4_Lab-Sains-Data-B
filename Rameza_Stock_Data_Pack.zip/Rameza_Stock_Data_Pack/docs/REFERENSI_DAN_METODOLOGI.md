# Referensi dan metodologi data

Tanggal penyusunan: 6 November 2026.

## Sumber resmi yang dapat digunakan

1. **BPS Kota Semarang — Jumlah Penduduk Menurut Kecamatan dan Jenis Kelamin (Jiwa), 2025.**
   URL: https://semarangkota.bps.go.id/id/statistics-table/2/NzgjMg%3D%3D/jumlah-penduduk-menurut-jenis-
   Angka Tembalang yang ditampilkan: laki-laki 101.772 jiwa dan perempuan 103.093 jiwa. Total 204.865 dihitung dengan menjumlahkan kedua angka tersebut.
   Kegunaan: konteks demografi wilayah. Bukan jumlah konsumen warung, bukan jumlah mahasiswa, dan bukan ukuran permintaan produk warung.

2. **BPS Kota Semarang — Kecamatan Tembalang Dalam Angka 2025.**
   Portal publikasi Pemerintah Kota Semarang:
   https://pustakadata.semarangkota.go.id/public/publikasi/bps/c4a40915d869bcb3e36b51aa
   Nomor katalog 1102001.3374070; nomor publikasi 33740.25023; rilis 26 September 2025.
   Kegunaan: sumber konteks kecamatan. Baca tabel yang relevan langsung dari publikasi sebelum mengambil angka rinci.

3. **BPS Kota Semarang — Kota Semarang Dalam Angka 2025.**
   URL: https://semarangkota.bps.go.id/id/publication/2025/02/28/e4acda942390244ca5c1d08b/semarang-municipality-in-figures-2025.html
   Rilis 28 Februari 2025. Berisi indikator lintas sektor Kota Semarang.
   Kegunaan: konteks kota, bukan data khusus objek warung.

4. **BPS — Statistik Penyediaan Makanan Minuman 2024.**
   URL: https://www.bps.go.id/id/publication/2025/12/31/e46a55af756331ede8016b91/statisti
   Rilis 31 Desember 2025. Abstraksi menyebut publikasi menyajikan karakteristik usaha, tenaga kerja, penjualan, dan pengeluaran; jumlah usaha penyediaan makanan-minuman Indonesia tahun 2024 disebut sekitar 5,28 juta usaha.
   Kegunaan: latar belakang sektor secara nasional. Jangan menyebut angka nasional sebagai jumlah UMKM/warung di Tembalang.

5. **Bank Indonesia — Pusat Informasi Harga Pangan Strategis Nasional (PIHPS).**
   URL: https://www.bi.go.id/Hargapangan/Website
   Menyediakan pemantauan harga komoditas seperti beras, cabai, daging ayam, gula, minyak goreng, dan telur menurut pilihan wilayah/pasar/periode.
   Kegunaan: pembanding harga eksternal. Pilih wilayah, pasar, komoditas, tanggal, dan satuan yang sesuai lalu catat hasil serta tanggal akses. Paket ini tidak mengarang angka harga.

## Metode pengumpulan data primer
- Wawancara pemilik/pegawai tentang alur pengecekan dan pencatatan stok.
- Observasi fisik bahan, satuan, lokasi penyimpanan, dan cara menghitung.
- Dokumentasi catatan stok/pembelian yang diizinkan pemilik.
- Uji coba aplikasi dan pencatatan hasil pengujian.

## Aturan keandalan
- Data penduduk dan statistik sektor adalah data sekunder; stok warung harus berasal dari data primer objek.
- Catat sumber, tanggal pengambilan, satuan, dan siapa yang mengonfirmasi.
- Jika informasi tidak tersedia, tulis “belum diperoleh”, jangan mengisi angka perkiraan seolah-olah fakta.
- Data harga pasar berubah menurut waktu, lokasi, jenis pasar, kualitas dan satuan. Simpan tangkapan/ekspor bukti saat pengambilan jika akan dikutip.
- Sebelum mengutip angka detail dari publikasi, buka tabel aslinya dan catat nomor tabel serta halaman.
