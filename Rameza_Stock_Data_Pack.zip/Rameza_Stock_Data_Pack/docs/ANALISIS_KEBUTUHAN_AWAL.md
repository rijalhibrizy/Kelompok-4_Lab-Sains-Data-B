# Analisis kebutuhan awal Rameza Stock

## 1. Ruang lingkup
Rameza Stock berfokus pada pencatatan dan pemantauan persediaan bahan makanan warung makan. Pengguna melakukan pemeriksaan fisik, kemudian memasukkan jumlah terbaru secara manual.

## 2. Alur kerja yang dituju
1. Pegawai memeriksa bahan secara fisik.
2. Pegawai menyampaikan hasil pemeriksaan kepada admin/pemilik.
3. Admin memilih bahan dan memasukkan jumlah stok terbaru, waktu pemeriksaan, petugas, dan catatan.
4. Sistem menyimpan stok terbaru dan histori stok sebelumnya.
5. Dashboard menghitung status berdasarkan batas minimum yang telah ditetapkan pemilik.

## 3. Kebutuhan fungsional awal
- Mengelola master bahan: kode, nama, kategori, satuan, batas minimum.
- Memasukkan stok awal yang diverifikasi.
- Memperbarui jumlah stok secara manual.
- Menyimpan stok sebelum, stok sesudah, selisih, waktu, petugas, dan catatan.
- Menampilkan status cukup/menipis/habis berdasarkan aturan yang disepakati.
- Mencari dan memfilter data serta riwayat.
- Menampilkan laporan persediaan dan mengekspor data.

## 4. Kebutuhan nonfungsional
- Antarmuka berbahasa Indonesia dan mudah dipahami.
- Validasi nilai stok tidak negatif.
- Satuan konsisten.
- Akses pengguna sesuai peran.
- Data tersimpan di basis data, bukan hanya state browser.
- Riwayat perubahan tidak hilang saat stok diperbarui.
- Backup dan perlindungan kredensial.

## 5. Batasan dan asumsi yang harus divalidasi
- Tidak ada pengurangan stok otomatis dari transaksi penjualan.
- Jumlah stok aktual hanya dapat diisi setelah observasi/konfirmasi warung.
- Batas minimum bukan angka universal; tentukan bersama pemilik.
- Modul pemasok/pembelian hanya dimasukkan jika memang diperlukan dan datanya tersedia.
- Kesesuaian dengan persyaratan tugas P9 (ERP, SCM, CRM, jumlah modul, basis data bersama, dan alur otomatis) harus dibandingkan dengan lembar instruksi resmi dosen. Modul inventori saja tidak otomatis memenuhi seluruh persyaratan.

## 6. Data yang masih harus dikumpulkan
- Profil usaha dan izin penggunaan nama/foto.
- Daftar bahan aktual.
- Stok fisik awal dan satuan.
- Batas minimum per bahan.
- Proses pengecekan dan pembelian saat ini.
- Pemasok aktual (jika relevan).
- Masalah yang dikonfirmasi pemilik/pegawai.
- Hasil uji coba aplikasi.
